const model = require("../models/foodModel.js");

// // ---------------------------------hard code----------------------------------------------
// let food = "Apple";
// let category = "Fruits"
// // ---------------------------------hard code----------------------------------------------

module.exports.readAllFood = (req, res, next) => {
    const callback = (error, results, fields) => {
		if (error) {
			console.error("Error readAllFood:", error);
			res.status(500).json(error);
		} else res.status(200).json(results);
	};

	model.selectAll(callback);
}

module.exports.readFoodByFoodName = (req, res, next) => {
    const data = {
        food_name: req.params.name
    };

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error: readFoodByFoodName", error);
            res.status(500).json(error);
        } else {
            if (results.length === 0) {
                res.status(404).json({
                    message: "Food Item not found",
                });
            } else {
                res.status(200).json(results);
            }
        }
    }

    model.selectByFoodName(data, callback);
}


module.exports.readFoodByCategory = (req, res, next) => {
    const data = {
        food_category: req.params.category
    };

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error: readFoodByCategory", error);
            res.status(500).json(error);
        }else {
            if (results.length === 0) {
                res.status(404).json({
                    message: "Food Item not found",
                });
            } else {
                res.status(200).json(results);
            }
        }
    }
    
    model.selectByCategory(data, callback)
}
