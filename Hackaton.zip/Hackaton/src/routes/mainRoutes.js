const express = require("express");
const router = express.Router();
const controller = require("../controllers/foodController");

router.get("/", controller.readAllFood); // GET all food
router.get("/foodname/:name", controller.readFoodByFoodName); // GET by food name
router.get("/category/:category", controller.readFoodByCategory); // GET by category

module.exports = router;
