const pool = require("../services/db");

const SQLSTATEMENT = `
DROP TABLE IF EXISTS food_data;


CREATE TABLE food_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    food_item VARCHAR(255) NOT NULL,
    category VARCHAR(255) NOT NULL,
    calories INT NOT NULL
);

INSERT INTO food_data (food_item, category, calories) VALUES
('Apple', 'Fruits', 52),
('Banana', 'Fruits', 89),
('Grapes', 'Fruits', 67),
('Orange', 'Fruits', 47),
('Strawberry', 'Fruits', 33),
('Kiwi', 'Fruits', 41),
('Mango', 'Fruits', 60)
`;

pool.query(SQLSTATEMENT, (error, results, fields) => {
	if (error) {
		console.error("Error creating tables:", error);
	} else {
		console.log("Tables created successfully", results);
	}
	process.exit();
});
