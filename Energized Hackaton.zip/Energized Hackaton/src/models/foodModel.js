const pool = require("../services/db");

module.exports.selectAll = (callback) => {
	const SQLSTATEMENT = `
    SELECT * FROM food_data;
    `;
	pool.query(SQLSTATEMENT, callback);
};

module.exports.selectByFoodName = (data, callback) => {
	const SQLSTATEMENT = `
    SELECT food_item, calories FROM food_data
    WHERE food_item = ?;
    `;
	const VALUES = [data.food_name];

	pool.query(SQLSTATEMENT, VALUES, callback);
};

module.exports.selectByCategory = (data, callback) => {
	const SQLSTATEMENT = `
    SELECT food_item, calories FROM food_data
    WHERE category = ?;
    `;
	const VALUES = [data.food_category];

	pool.query(SQLSTATEMENT, VALUES, callback);
};
